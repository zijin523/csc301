const {
  override,
  fixBabelImports,
  addWebpackAlias,
  addDecoratorsLegacy,
} = require('customize-cra');
const rewirePostcss = require('react-app-rewire-postcss');
const px2rem = require('postcss-px2rem-exclude');

module.exports = override(addDecoratorsLegacy(), (config, env) => {
  // 重写postcss
  rewirePostcss(config, {
    plugins: () => [
      // require("postcss-flexbugs-fixes"),
      // require("postcss-preset-env")({
      //     autoprefixer: {
      //         flexbox: "no-2009",
      //     },
      //     stage: 3,
      // }),
      //关键:设置px2rem
      px2rem({
        remUnit: 16,
        propWhiteList: ['font-size'],
        selectorBlackList: ['ant', /^html$/],
        exclude: /node_modules/i,
      }),
    ],
  });

  return config;
});
