import axios from 'axios';

// 接口请求部分
const instance = axios.create({
  timeout: 3000,
});

instance.interceptors.request.use(
  (req) => {
    const token = localStorage.getItem('token');
    if (token) {
      console.log(req);
      req.defaults.headers.common['Authorization'] = 'Bearer ' + token;
    }
    return req;
  },
  (err) => {
    return Promise.reject(err);
  }
);

instance.interceptors.response.use(
  (res) => {
    return res;
  },
  (err) => {
    return err.response;
  }
);

export const getAllCampSite = (params) => {
  let url = '/api/post/?campsite_id=' + params.campId;

  url += `&date=${params.date || 'all'}`;

  url += `&email=all`

  url += `&name=${params.username || 'all'}`;

  return fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(function (data) {
      return data.json();
    })
    .then(function (data) {
      console.log(data);
      return data;
    });
};

export const getByLonlat = (params) => {
  return fetch(`/api/campsite/nearby/?lat=${params.lat}&lon=${params.lon}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(function (data) {
      return data.json();
    })
    .then(function (data) {
      console.log(data);
      return data;
    });
};

export const getCampsite = (params) => {
  return fetch(`/api/campsite/${params.id}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },

  })
    .then(function (data) {
      return data.json();
    })
    .then(function (data) {
      console.log(data);
      return data;
    });
};

export const getData = (params) => {
  return fetch(`api/spotlight/park/${params.id}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(function (data) {
      console.log(data);
      return data;
    })
    .then(function (data) {
      return data.json();
    });
};

export const getPost = (params) => {
  console.log("getpost");
  return fetch(`api/post/?campsite_id=${params.campsiteId}&date=${params.date}&email=${params.email}&name=${params.name}`, 
  {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then(function (data) {
      console.log(data);
      return data;
    })
    .then(function (data) {
      return data.json();
    });
};

export const delPost = (params) => {
  const str = 'Bearer '+ params.token;
  return fetch(`api/post/${params.id}`, 
  {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': str,
    },
  })
    .then(function (data) {
      return data.json();
    });
}
// export const getCampSite = (params) => {
//   const date = params.date;
//   return fetch(`/api/post?campsite_id=1&date=${date}`, {
//     method: 'GET',
//     headers: {
//       'Content-Type': 'application/json',
//     },
//   })
//     .then(function (data) {
//       return data.json();
//     })
//     .then(function (data) {
//       console.log(data);
//       return data;
//     });

//   console.log('getCampSite 查询参数是', params);
//   return Promise.resolve({
//     // campSite 数据
//     data: [
//       {
//         date: 'Oct 2, 2022',
//         list: [
//           {
//             images: [sp2],
//             text: 'Lorem ipsum dolor sit amet, test link consectetur adipiscing elit. Strong text pellentesque ligula commodo viverra vehicula. Italic text at ullamcorper enim. Morbi a euismod nibh. Underline text non elit nisl. Deleted text tristique, sem id condimentum tempus, metus lectus venenatis mauris, sit amet semper lorem felis a eros. Fusce egestas nibh at sagittis auctor. Sed ultricies ac arcu quis molestie. Donec dapibus nunc in nibh egestas, vitae volutpat sem iaculis. Curabitur sem tellus, elementum nec quam id, fermentum laoreet mi. Ut mollis ullamcorper turpis, vitae facilisis velit ultricies sit amet. Etiam laoreet dui odio, id tempus justo tincidunt id. Phasellus scelerisque nunc sed nunc ultricies accumsan.',
//           },
//           {
//             images: [sp1, sp2, sp3],
//             text: 'Lorem ipsum dolor sit amet, test link consectetur adipiscing elit. Strong text pellentesque ligula commodo viverra vehicula. Italic text at ullamcorper enim. Morbi a euismod nibh. Underline text non elit nisl. Deleted text tristique, sem id condimentum tempus, metus lectus venenatis mauris, sit amet semper lorem felis a eros. Fusce egestas nibh at sagittis auctor. Sed ultricies ac arcu quis molestie. Donec dapibus nunc in nibh egestas, vitae volutpat sem iaculis. Curabitur sem tellus, elementum nec quam id, fermentum laoreet mi. Ut mollis ullamcorper turpis, vitae facilisis velit ultricies sit amet. Etiam laoreet dui odio, id tempus justo tincidunt id. Phasellus scelerisque nunc sed nunc ultricies accumsan.',
//           },
//           {
//             images: [sp4, sp3, sp1],
//             text: 'Lorem ipsum dolor sit amet, test link consectetur adipiscing elit. Strong text pellentesque ligula commodo viverra vehicula. Italic text at ullamcorper enim. Morbi a euismod nibh. Underline text non elit nisl. Deleted text tristique, sem id condimentum tempus, metus lectus venenatis mauris, sit amet semper lorem felis a eros. Fusce egestas nibh at sagittis auctor. Sed ultricies ac arcu quis molestie. Donec dapibus nunc in nibh egestas, vitae volutpat sem iaculis. Curabitur sem tellus, elementum nec quam id, fermentum laoreet mi. Ut mollis ullamcorper turpis, vitae facilisis velit ultricies sit amet. Etiam laoreet dui odio, id tempus justo tincidunt id. Phasellus scelerisque nunc sed nunc ultricies accumsan.',
//           },
//         ],
//       },
//       {
//         date: 'Oct 12, 2022',
//         list: [
//           {
//             images: [sp3, sp4],
//             text: 'Lorem ipsum dolor sit amet, test link consectetur adipiscing elit. Strong text pellentesque ligula commodo viverra vehicula. Italic text at ullamcorper enim. Morbi a euismod nibh. Underline text non elit nisl. Deleted text tristique, sem id condimentum tempus, metus lectus venenatis mauris, sit amet semper lorem felis a eros. Fusce egestas nibh at sagittis auctor. Sed ultricies ac arcu quis molestie. Donec dapibus nunc in nibh egestas, vitae volutpat sem iaculis. Curabitur sem tellus, elementum nec quam id, fermentum laoreet mi. Ut mollis ullamcorper turpis, vitae facilisis velit ultricies sit amet. Etiam laoreet dui odio, id tempus justo tincidunt id. Phasellus scelerisque nunc sed nunc ultricies accumsan.',
//           },
//         ],
//       },
//       {
//         date: 'Oct 14, 2022',
//         list: [
//           {
//             images: [sp4, sp3, sp2, sp1],
//             text: 'Lorem ipsum dolor sit amet, test link consectetur adipiscing elit. Strong text pellentesque ligula commodo viverra vehicula. Italic text at ullamcorper enim. Morbi a euismod nibh. Underline text non elit nisl. Deleted text tristique, sem id condimentum tempus, metus lectus venenatis mauris, sit amet semper lorem felis a eros. Fusce egestas nibh at sagittis auctor. Sed ultricies ac arcu quis molestie. Donec dapibus nunc in nibh egestas, vitae volutpat sem iaculis. Curabitur sem tellus, elementum nec quam id, fermentum laoreet mi. Ut mollis ullamcorper turpis, vitae facilisis velit ultricies sit amet. Etiam laoreet dui odio, id tempus justo tincidunt id. Phasellus scelerisque nunc sed nunc ultricies accumsan.',
//           },
//         ],
//       },
//     ],
//   });
// };

export const login = (params) =>
  instance.post('/api/auth/token/', params, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
  });