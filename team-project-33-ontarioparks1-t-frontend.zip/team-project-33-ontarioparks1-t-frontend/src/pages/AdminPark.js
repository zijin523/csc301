import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import Campsite from "../components/Campsite/Campsite";
// import axios from 'axios';
// import qs from 'qs';

import './parks.css';

export default function Parks() {

    const navigate = useNavigate();
    const [userInput, setUserInput] = useState("");
    const [parks, setParks] = useState([]);

    const changeHandeler = (event) => {
        var value = event.target.value;
        setUserInput(value);
        console.log(value);
    };

    const getparks = () => {
        fetch(`/api/park/?all`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
          })
            .then(function (data) {
                return data.json()
            })
            .then(function (data) {
                setParks(data);
                //console.log(data);
            });
    };

    const goCreate = () => {
        navigate("/CreatePark");
    };

    const ViewCamp = (event) => {
        var target_name = event.target.name;
        var target_id = event.target.id;
        navigate("/AdminCampsite", {state : {name : target_name, id : target_id}});
    }

    // const deleteParks = (event) =>{
    //     var toDelete = event.target.id;
    //     for (var i = 0; i < parks.length; i++){
    //         if (parks[i].id == toDelete){

    //         }
    //     }
    // };

    const handleBack = () => {
        navigate("/AdminMain");
    }

    getparks();

    return(
        <div className="parksPage">
        <h4 className="title">All Parks</h4>
        <br/>
        <input
            className = "searchBar"
            type = "text"
            value = {userInput}
            onChange = {changeHandeler}
            placeholder = "Search by the park name"
        />
        <br/>
        {parks.filter(
            (s) => s.park_name.includes(userInput)
        ).map((s) => (
                <div key={s.id} className="parksDisplay">
                <h4>id : {s.id}<br/>
                name : {s.park_name}
                <br/>
                latitude : {s.lat}
                <br/>
                longtitude : {s.lon}
                <br/>
                Street Address : {s.street_addr}
                <br/>
                <button id={s.id} name={s.park_name} className="View Campsite" onClick={ViewCamp}>View Campsites</button>
                {/* <button id={s.id} className="Delete" onClick={deleteParks}>Delete Park</button> */}
                </h4>
                </div>
            ))}
        <br/>
        <button className="Button" onClick={goCreate}>Create Park</button>
        <button className="Button" onClick={handleBack}>Back</button>
        </div>
    );

}