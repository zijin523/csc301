import ImageSlider from "../components/ImageSlider/ImageSlider.jsx";
import classes from "../components/Style.module.css";
import { useNavigate} from "react-router-dom";
import './MainPage.css';
import React, { useEffect, useState } from "react";
import { getCampsite, getData } from '../apis';

function Spotlight(){
    const [data, setData] = useState([]);
    const [parkId, setParkId] = useState('1');
    const campsiteId = JSON.parse(localStorage.getItem("cid"));
    //console.log(campsiteId)
    useEffect(() => {
        if (campsiteId != null){
            getCampsite({id: campsiteId}).then( (data)=> {
                console.log(data);
                setParkId(data.park_id);
            });
        }
      }, []);

    useEffect(() => {
        getData({id: parkId}).then((data) => {
            console.log(parkId);
            console.log(data);
            setData(data);
          });
    }, [parkId]);

    const weatherTime = {
        time: "Nov 28, 2022", 
        temp: "3°C",
        weather: "Raining"
    }

    const navigate = useNavigate();

    const goMain = () =>{
        navigate('/', {replace: true});
    };

    return(
        <div className="main">
            <div className="menu-item" 
            style={{display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'}} 
            onClick={goMain}>
            <img
              src={'https://cdn-icons-png.flaticon.com/512/17/17699.png'}
              width={60}
              height={60}
              alt={"main"}
            />
          </div>
            <h1 className={classes.header}>Spotlight</h1>
            <div className={classes.containerStyle}>
            {data.map((item) => {
            const { images } = item;
            return (
                    <ImageSlider images={images} content={""}/>
            );
            })}
                <div className={classes.smallBoard}>
                    <div className={classes.smallFont}>
                        {weatherTime.time}
                        <br></br>
                        {weatherTime.temp} {weatherTime.weather}
                    </div> 
                </div>
                <br></br>
                <div style={{fontSize: 'xx-large', fontFamily: 'Verdana, Geneva, Tahoma, sans-serif'}}>Welcome to the Campsite!</div>
                <div className={classes.paragraphBoard}>
                {data.map((item) => {
                const { content } = item;
                return (
                    <p className={classes.smallFont}>{content}</p>
                );
                })}
                    
                </div>
            </div>

        </div>
    );

}

export default Spotlight;