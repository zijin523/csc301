import './MainPage.css';
import '../components/Campsite/Campsite.css';
import { SearchBar} from 'antd-mobile';
import { useEffect, useState, useRef } from 'react';
import { useNavigate} from "react-router-dom";
import { getPost } from '../apis';
import PostComp from '../components/PostComp/PostComp.js';
import {delPost} from '../apis/index.js';

function AdminPost(){
    const token = localStorage.getItem('token');
    const [campsiteId, setCampsiteId] = useState("all");
    const [clickAll, setClickAll] = useState(false);
    const navigate = useNavigate();
    const [posts, setPosts] = useState([]);

    function showAllPost(){
        const not = !clickAll;
        setClickAll(not);
    }

    useEffect(() =>{
        const params = {campsiteId: "all", date: "all", email: "all", name: "all"};
        getPost( params ).then((data) => {
            console.log(data);
            setPosts(data);
          });  
    }, [clickAll]);

    const deletePost=(id) => {
        const params = {id: id, token: token};
            console.log(params.token);
            delPost(params);
            get();
        return;
    };
    
  const get = () => {
    const params = {campsiteId: campsiteId, date: 'all', email: 'all', name: 'all'};
        console.log("onsearch");
        getPost( params ).then((data) => {
            setPosts(data);
          });
  };

  const onSearch = () => {
    get();
  };

    function goMain(){
        navigate('/AdminMain', {replace: true});
    }
    return(
        <div className="main">
            <h4 className="main-title">
                WELCOME TO ADMIN POST PAGE!
            </h4>
            <button onClick={goMain}>go back</button>
            <button onClick={showAllPost}>view all posts</button>
            <div className="search-bar">
                <SearchBar
                placeholder="input campsite number (e.g. 1)"
                value={campsiteId}
                onChange={()=>{setCampsiteId(campsiteId)}}
                onSearch={onSearch}
                />
            </div>
            <div>
            {posts.map((item, index) => {
            const { id, campsite_id, content, email, name, post_time, images } = item;
            return(
                <div>
                <PostComp key={id} id={id} campsite_id={campsite_id} content={content} email={email} name={name} post_time={post_time} images={images}/>
                <button key={index} onClick={deletePost(id)}>delete</button>
                </div>
                );
            })}
            </div>

        </div>
    );

};

export default AdminPost;