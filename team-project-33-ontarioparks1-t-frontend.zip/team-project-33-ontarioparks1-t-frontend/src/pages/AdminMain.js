import './AdminMain.css';
import '../components/Campsite/Campsite.css';
import { useNavigate } from 'react-router-dom';
import post from '../assets/post.png';
import campsite from '../assets/campsite.png';
import park from '../assets/park.png';
import logout from '../assets/logout.png';
function AdminMain(){
    const navigate = useNavigate();
    
    const first_menus = [{
            name: 'Posts',
            icon: post,
            onClick: () => {
            navigate('/AdminPost');},},
        {
            name: 'AdminCamp',
            icon: campsite,
            onClick: () => {
            navigate('/AdminCamp');
          },},
    ];

    const second_menus = [
        {
            name: 'AdminPark',
            icon: park,
            onClick: () => {
            navigate('/AdminPark');
            },},
        {
            name: 'Logout',
            icon: logout,
            onClick: () => {
            localStorage.removeItem('token');
            navigate('/Login');
        },
    },];
        
          
    return(
        <div id="background" className="main">
            <h4 className="main-title">
                WELCOME TO ADMIN PAGE!
            </h4>
            <div className="bar">
                <div className="main-menu">
                    {first_menus.map((item) => (
                        <div className="menu-item" key={item.name}>
                        <span>{item.name}</span>
                        <img
                        src={item.icon}
                        className="menu-item-icon"
                        onClick={item.onClick}
                        alt={item.name}
                        />
                        </div>
                    ))}
                </div>

                <div className="main-menu">
                    {second_menus.map((item) => (
                        <div className="menu-item" key={item.name}>
                        <span>{item.name}</span>
                        <img
                        src={item.icon}
                        className="menu-item-icon"
                        onClick={item.onClick}
                        alt={item.name}
                        />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
export default AdminMain;