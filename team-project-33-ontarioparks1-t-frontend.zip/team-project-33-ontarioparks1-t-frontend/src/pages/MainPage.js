import { useState, useEffect } from 'react';

import calender from '../assets/calender.png';
import map from '../assets/map.png';
import post from '../assets/post.png';
import spotlight from '../assets/spotlight.png';
import admin from '../assets/admin.png';

import { Modal, Calendar, SearchBar, Toast } from 'antd-mobile';
import { formatDate, timestampConveter, getLongLat } from '../utils';
import { getAllCampSite, getByLonlat } from '../apis';
import Weather from '../components/Weather/Weather';

import './MainPage.css';
import ImageSlider from '../components/ImageSlider/ImageSlider';

import { useNavigate } from 'react-router-dom';

const today = new Date();
const campName = 'Campsite';

function MainPage() {
  const navigate = useNavigate();
  const [date, setDate] = useState();
  const [calendarVisible, setCalenderVisible] = useState(false);
  const [username, setUsername] = useState();
  const [campId, setCampId] = useState('1');

  const [data, setData] = useState([]);

  useEffect(() => {
    Toast.show({ icon: 'loading', content: 'loading...' });
    getLongLat().then((pos) => {
      console.log('position:', pos);
      getByLonlat({
        lon: pos.lon,
        lat: pos.lat,
      })
        .then((data) => {
          Toast.clear();
          if (Array.isArray(data) && data.length > 0) {
            setCampId(data[0].id);
          }
        })
        .then(() => get(date));
    });
  }, []);

  localStorage.setItem('cid', campId);
  
  const get = (_date) => {
    console.log("52", date);
    const params = {
      campId,
      username,
      date: _date ? formatDate(_date) : undefined,
    };
    console.log("58",date);
    getAllCampSite(params).then((data) => {
      setData(data);
    });
  };

  const onSearch = () => {
    get(date);
  };

  const menus = [
    {
      name: 'Calender',
      icon: calender,
      onClick: () => {
        setCalenderVisible(true);
      },
    },
    {
      name: 'Map',
      icon: map,
      onClick: () => {
        navigate('/Map');
      },
    },
    {
      name: 'Posts',
      icon: post,
      onClick: () => {
        navigate('/Posts');
      },
    },
    {
      name: 'Spotlight',
      icon: spotlight,
      onClick: () => {
        navigate('/Spotlight');
      },
    }, //传递参数 /url?参数1=x&&参数2=y
    {
      name: 'Login',
      icon: admin,
      onClick: () => {
        navigate('/Login');
      },
    },
  ];

  const onCalendarChange = (_date) => {
    console.log("_date",_date)
    setDate(_date)
    console.log("date", date)
    setCalenderVisible(false);
    setTimeout(() => {
      get(_date);
    }, 0);
  };

  const handleLoginClick = () => {
    navigate('/Login')
  }

  const isLogged = localStorage.getItem('token');


  return (
    <main className="main">
      <h4 className="main-title">
        WELCOME TO <b>{campName + campId}</b> !
      </h4>

      <div className="search-bar">
        <SearchBar
          placeholder="Username"
          value={username}
          onChange={setUsername}
          onSearch={onSearch}
        />
      </div>

      <div className="main-menu">
        <Weather date={formatDate(today)} temp={'3℃'} desc={'Raining'} />
        {menus.map((item) => (
          <div className="menu-item" key={item.name}>
            <img
              src={item.icon}
              className="menu-item-icon"
              onClick={item.onClick}
              alt={item.name}
            />
          </div>
        ))}
      </div>

      <div className="campsite">
        {data.map((item) => {
          const { post_time, images, content } = item;
          return (
            <div className="campsite-item" key={post_time}>
              <div className="campsite-title">
                {timestampConveter(post_time)}
              </div>
              <ImageSlider images={images} content={content} />
            </div>
          );
        })}
      </div>

      <Modal
        visible={calendarVisible}
        closeOnMaskClick
        content={
          <Calendar
            value={date}
            selectionMode="single"
            onChange={onCalendarChange}
          />
        }
        onClose={() => {
          setCalenderVisible(false);
        }}
      />
    </main>
  );
}
export default MainPage;
