import React, { useState } from "react";
import {useNavigate} from 'react-router-dom';
import axios from 'axios';
import qs from 'qs';

import './parks.css';

export default function CreateParks() {

    const navigate = useNavigate();
    const [park_name, setPark_name] = useState('');
    const token = localStorage.getItem("token");

    const [street_addr, setStreet_addr] = useState('');
    const [lat, setLat] = useState('');
    const [lon, setLon] = useState('');

    const handleBack = () => {
        navigate("/AdminPark");
    };

    const handleInputChange = (event) => {
        const target = event.target;
        const key = target.name;
        const value = target.value;
        if (key == 'park_name'){
            setPark_name(value);
        } else if (key == 'street_addr') {
            setStreet_addr(value);
        } else if (key == 'lat') {
            setLat(value);
        } else if (key == 'lon') {
            setLon(value);
        } 
    };

    const handleSubmit = (event) => {
        
        event.preventDefault();
        try{
            var lat_float = parseFloat(lat);
            console.log(lat_float);
            var lon_float = parseFloat(lon);
            if (lat_float < -180 || lat_float > 180){
                alert("Please enter correct latitude!");
            } else if (lon_float < -180 || lon_float > 180){
                alert("Please enter correct longitude!");
            } else if (park_name == ""){
                alert("Park name can not be empty!");
            } else if (street_addr == ""){
                alert("Street address can not be empty!")
            } else {
                axios.post("/api/park/add/", qs.stringify({
                    'park_name' : park_name,
                    'street_addr' : street_addr,
                    'lat' : lat,
                    'lon' : lon
                }) , {headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer '+ token
                }})
                .then(response => {
                    console.log(response);
                })
        
                .catch(err => {
                    //alert(err);
                    console.log(err);
                });
    
                handleBack();

                }
            } catch (e){
                alert("Please enter correct latitude!");
            }
    };

    return(
        <div className = "parksPage">
        <h1 className = "title">New Park </h1>
        <button className = "back_button" onClick = {handleBack}>Back</button>
        <form>
            <h4 className = "words">Park Name:</h4>
            <input
                name="park_name"
                className="singlerow_text"
                type="text"
                value={park_name}
                onChange={handleInputChange} />
            <h4 className = "words">Street Address:</h4>
            <input
                name="street_addr"
                className="singlerow_text"
                type="text"
                value={street_addr}
                onChange={handleInputChange} />
            <h4 className = "words">latitude:</h4>
            <input
                name="lat"
                className="singlerow_text"
                type="text"
                value={lat}
                onChange={handleInputChange} />
            <h4 className = "words">Longtitude</h4>
            <input
                name="lon"
                className="singlerow_text"
                type="text"
                value={lon}
                onChange={handleInputChange} />
            <br />
            <button type="submit" value="Submit" className = 'submit_button' onClick={handleSubmit}>submit</button>
        </form>
        </div>
    );

}