import React, { useState } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
// import axios from 'axios';
// import qs from 'qs';

import './parks.css';

export default function Campsite(props) {

    const navigate = useNavigate();
    const location = useLocation();
    const [userInput, setUserInput] = useState("");
    const [camp, setCamp] = useState([]);

    const changeHandeler = (event) => {
        var value = event.target.value;
        setUserInput(value);
        console.log(value);
    };

    const park_name = location.state.name;
    console.log(park_name);
    const park_id = location.state.id;

    const getcampsites = () => {
        fetch(`/api//campsite/park/${park_id}/ `, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
          })
            .then(function (data) {
                return data.json()
            })
            .then(function (data) {
                setCamp(data);
                //console.log(data);
            });
    };

    const goCreate = () => {
        navigate("/CreateCampsite");
    };

    const handleBack = () => {
        navigate("/AdminPark");
    }

    const deleteParks = (event) =>{
        //var toDelete = event.target.id;
    };

    getcampsites();

    return(
        <div className="parksPage">
        <h4 className="title">All Campsites in {park_name}</h4>
        <br/>
        <input
            className = "searchBar"
            type = "text"
            value = {userInput}
            onChange = {changeHandeler}
            placeholder = "Search by the park ID"
        />
        <br/>
        {camp.filter(
            (s) => String(s.id).includes(userInput)
        ).map((s) => (
                <div className="parksDisplay">
                <h4>id : {s.id}<br/>
                name : {s.name}
                <br/>
                latitude : {s.lat}
                <br/>
                longtitude : {s.lon}
                <br/>
                Park_id : {s.park_id}<br/>
                <button id={s.id} className="Delete" onClick={deleteParks}>Delete Campsite</button>
                </h4>
                </div>
            ))}
        <br/>
        <button className="Button" onClick={goCreate}>Create Campsite</button>
        <button className="Button" onClick={handleBack}>Back</button>
        </div>
    );
}