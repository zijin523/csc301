import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Form, Input, Button, Toast } from 'antd-mobile';
import { login } from '../apis';
import './Login.css';

function Login() {
  const navigate = useNavigate();

  const onFinish = (values) => {
    login(values).then((resp) => {
      if (resp.status < 300) {
        Toast.show({
          content: 'Login successful',
          afterClose: () => {
            navigate('/AdminMain');
            localStorage.setItem('token', resp?.data?.access_token);
          },
        });
      } else {
        Toast.show({
          content: resp.data.msg,
        });
      }
      console.log(resp);
    });
  };

  const goBack = () =>{
    navigate('/', {replace: true});
  };
    
  return (
    
    <div
      className="login"
      style={{
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'column',
        padding: 16,
        minHeight: '100vh',
      }}
    >
      <h1 style={{ marginBottom: 24 }}>Admin Login</h1>
      <button className="back" onClick={goBack}> Back </button>
      <Form
        layout="horizontal"
        footer={
          <Button block type="submit" color="primary" size="large">
            Log in
          </Button>
        }
        onFinish={onFinish}
      >
        <Form.Item
          name="email"
          label="Email"
          rules={[{ required: true, message: 'Email is required' }]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          name="passwd"
          label="password"
          rules={[{ required: true, message: 'Password is required' }]}
        >
          <Input type="password" />
        </Form.Item>
      </Form>
    </div>
  );
}

export default Login;
