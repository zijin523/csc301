import classes from "../components/Style.module.css";
import './MainPage.css';
import './Map.css';
import {useNavigate} from 'react-router-dom';
import { useEffect, useState } from "react";
import { getLongLat } from '../utils';
import { getByLonlat } from '../apis';
import { GoogleMap, useLoadScript, Marker } from "@react-google-maps/api";
import CusMarker from "../components/Campsite/CusMarker.js";
import Campsite from "../components/Campsite/Campsite.js";

function Map(){
    const [location, setLocation] = useState();
    const [nearby, setNearby] = useState([]);
    const navigate = useNavigate();

    const goMain = () =>{
        navigate('/', {replace: true});
    };

    useEffect(() => {
        getLongLat().then((pos) => {
            setLocation({lat: pos.lat,
            lng: pos.lon});
            getByLonlat({lat:pos.lat, lon:pos.lon}).then((near) => {
                console.log(near);
                if ('lat' in near) {
                    setNearby({near});
                }
            });
        });
      }, []);

    const { isLoaded } = useLoadScript({ googleMapsApiKey: "AIzaSyD-t0EQdK4i9XfEhH56_RlTUT0ISleIA3k" });

    if(!isLoaded) return <div>Loading...</div>;
    

    return(
        <main className="main">
            <div className="menu-item" 
            style={{display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'}} 
            onClick={goMain}>
            <img
              src={'https://cdn-icons-png.flaticon.com/512/17/17699.png'}
              width={60}
              height={60}
              alt={"main"}
            />
          </div>
            <h1 className={classes.header}>Map</h1>
            <br></br>
            <div>
                <GoogleMap zoom={10} center={location} mapContainerClassName="map">
                    <Marker position={location}></Marker>
                    {nearby && nearby.map((item) => {
                    const {id, lat, lon} = item;
                    return (
                        <CusMarker key={id} lat={lat} lon={lon}></CusMarker>
                    );
                    })}
                </GoogleMap>
            </div>
            <div>
                <br></br>
            <div className="small-title">
                Checkout Nearby Campsites!
            </div>
            {nearby && nearby.map((item) => {
                const {id, park_id, name, lat, lon} = item;
            return (
                <div>
                <Campsite key={id} id={id} park_id={park_id} name={name} lat={lat} lon={lon}></Campsite>
                <br></br>
                </div>
            );
            })}
            </div>
        </main>
    );
}

export default Map;
