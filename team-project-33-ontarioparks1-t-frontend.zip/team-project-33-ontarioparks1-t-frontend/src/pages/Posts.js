import React, { createElement, useState } from "react";
import {useNavigate} from 'react-router-dom';
import axios from 'axios';
import qs from 'qs';

import './post.css';

export default function Post(prop) {

    const cam_name = 'Campsite';
    const cam_id = JSON.parse(localStorage.getItem("cid"));
    

    const endpoint = '/api/post/add';

    if (prop.name != null){
        cam_name = prop.name;
    }
    if (prop.cam_id != null){
        cam_id = prop.cam_id;
    }

    const navigate = useNavigate();

    const [content, setContent] = useState('');
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [comment, setComment] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [count, setCount] = useState(0);
    
    const handleInputChange = (event) => {
        const target = event.target;
        const key = target.name;
        const value = target.value;
        if (key == 'content'){
            setContent(value);
        } else if (key == 'email') {
            setEmail(value);
        } else if (key == 'username') {
            setUsername(value);
        } else if (key == 'comment') {
            setComment(value);
        } 
    };

    const handleSubmit = (event) => {

        event.preventDefault();

        if (email == ''){
            alert("Email can not be empty!");
        } else if (content == ''){
            alert("Content can not be empty!");
        } else {
            alert("Posted!");

            axios.post(endpoint,qs.stringify({
                'email': email,
                'name': username,
                'content': content,
                'campsite_id': cam_id,
                'images': imageUrl
            }))
            .then(response => {
                console.log(response);
            })
    
            .catch(err => {
                //alert(err);
                console.log(err);
            });

            handleBack();
        }

    };

    const handleBack = () => {
         navigate('/', {replace: true});
    };

    const handleUpload = (event) => {
        if (event.target.files.length != 0) {
            var urls = imageUrl;
            var img_src = URL.createObjectURL(event.target.files[0]);
            if (count == 0) {
                var new_urls = img_src;
            } else {
                var new_urls = urls + "," + img_src;
            }
            setCount(count + 1);
            setImageUrl(new_urls);
            changeInputType('text')
            changeInputType()
        }
    };
    // const onDeleteImg = (index) => {
    //     const images = imageUrl.split(',')
    //     images.splice(index, 1)
    //     // URL.revokeObjectURL(images[index])
    //     setImageUrl(images.join(','))
    //     setCount(count - 1)
    //     changeInputType()
    // }

    const display = () => {
        if (imageUrl) {
            const element = imageUrl.split(',').map((item, index)=>{
                return (
                    <div key={item} className="uploader-preview">
                        {/* <div className="uploader-preview-image"> */}
                        <img style={{ width: 100, height: 100 }} src={item}></img>
                        {/* </div> */}
                        {/* <div className="uploader-preview-delete" onClick={onDeleteImg.bind(this, index)}>
                            <i class="fa fa-camera-retro" aria-hidden="true"></i> */}
                        {/* </div> */}
                    </div>
                )
            })
            return element
        }
    }
    const addFileElement = () =>{
        if(count < 9){
            return (
                <div className="uploader-upload">
                    <input className="uploader-input" type="file" accept="image/*" onChange={handleUpload} />
                </div>
            )
        }
    }
    const changeInputType = (type = 'file') => {
        document.querySelector('.uploader-input').setAttribute('type', type)
    }

    return (
        <div className = "postPage">
        <h1 className = "title">New Post - {cam_name} {cam_id}</h1>
        <button className = "back_button" onClick = {handleBack}>Back</button>
        <form>
            <h4 className = "words">Media:</h4>
            <br />
            <div className="uploader-wrapper">
                {display()}
                {addFileElement()}
            </div>
            <br />
            <textarea
                name="content"
                className="content_text"
                type="text"
                rows = {5}
                value={content}
                onChange={handleInputChange} />
            <br />
            <h4 className = "words">Email*:</h4>
            <br />
            <input
                name="email"
                className="singlerow_text"
                type="text"
                value={email}
                onChange={handleInputChange} />
            <br />
            <h4 className = "words">Name:</h4>
            <br />
            <input
                name="username"
                className="singlerow_text"
                type="text"
                value={username}
                onChange={handleInputChange} />
            <br />
            <h4 className = "words">Any suggestions to improve Arrowhead?</h4>
            <br />
            <textarea
                name="comment"
                className="singlerow_text"
                type="text"
                row = {4}
                value={comment}
                onChange={handleInputChange} />
            <br />
            <button type="submit" value="Submit" className = 'submit_button' onClick={handleSubmit}>submit</button>
        </form>
        </div>
    );
}
