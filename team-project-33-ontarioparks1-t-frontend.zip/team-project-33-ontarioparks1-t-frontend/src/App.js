import './App.css';
import { Route, Routes} from 'react-router-dom';
import MainPage from './pages/MainPage';
import Map from './pages/Map';
import Posts from './pages/Posts';
import Spotlight from './pages/Spotlight';
import AdminMain from './pages/AdminMain';
import Login from './pages/Login';
import AdminPost from './pages/AdminPost';
import AdminPark from './pages/AdminPark';
import AdminCampsite from './pages/AdminCampsite';
import CreatePark from './pages/CreatePark';
import CreateCampsite from './pages/CreateCampsite';

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<MainPage/>} />
        <Route path="/Map" element={<Map/>} />
        <Route path="/Posts" element={<Posts/>} />
        <Route path="/Spotlight" element={<Spotlight/>} />
        <Route path="/AdminMain" element={<AdminMain/>}/>
        <Route path="/AdminPost" element={<AdminPost/>}/>
        <Route path="/Login" element={<Login />}/>
        <Route path="/AdminPark" element={<AdminPark />}/>
        <Route path="/AdminCampsite" element={<AdminCampsite />}/>
        <Route path="/CreatePark" element={<CreatePark />}/>
        <Route path="/CreateCampsite" element={<CreateCampsite />}/>
      </Routes>
    </div>
  );
}

export default App;