export function padLeftZero(str) {
  return ('00' + str).substr(str.length);
}

// Object date => 2022-11-02
export function formatDate(date, fmt = 'yyyy-MM-dd') {
  //获取年份
  if (/(y+)/.test(fmt)) {
    // 把数字变成字符串
    let dateY = date.getFullYear() + '';
    //RegExp.$1 在判断中出现过，且是括号括起来的，所以 RegExp.$1 就是 "yyyy"
    fmt = fmt.replace(RegExp.$1, dateY.substr(4 - RegExp.$1.length));
  }

  //获取其他
  let o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds(),
  };
  for (const k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      let str = o[k] + '';
      fmt = fmt.replace(
        RegExp.$1,
        RegExp.$1.length == 1 ? str : padLeftZero(str)
      );
    }
  }
  return fmt;
}

export function timestampConveter(date) {
  let unix_timestamp = date;

  var date = new Date(unix_timestamp * 1000);
  var month = parseInt(date.getMonth()) + 1;
  var formattedTime =
    date.getFullYear() + '-' + month.toString() + '-' + date.getDate();

  return formattedTime;
}

export function getLongLat() {
  const options = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0,
  };

  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          lon: pos.coords.longitude,
          lat: pos.coords.latitude,
        }),
      (err) => reject(new Error('ERROR(' + err.code + '): ' + err.message)),
      options
    );
  });
}
