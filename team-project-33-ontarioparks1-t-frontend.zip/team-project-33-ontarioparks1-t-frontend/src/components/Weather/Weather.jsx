import sun from '../../assets/sun.png';
import raining from '../../assets/rain.png';
import cloudy from '../../assets/cloud.png';
import './Weather.css';

const iconMap = {
  Raining: raining,
  Sun: sun,
  Cloudy: cloudy,
  // extension
};

function Weather(props) {
  console.log(props)
  const { date = '-', temp = '-', desc = '-' } = props;
  const icon = iconMap[desc]

  return (
    <div className="weather">
      <img src={icon} alt="weather" className="weather-icon" />

      <div className="weather-info">
        <div className="weather-date">{date}</div>
        <div className="weather-meta">
          <span style={{ marginRight: 4 }}>{temp}</span>
          <span>{desc}</span>
        </div>
      </div>
    </div>
  );
}

export default Weather;
