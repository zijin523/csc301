import './Campsite.css';
import { useNavigate } from "react-router-dom";
function Campsite(props){
    function handleClick(){
        const navigate = useNavigate();
        const {camp_id} = props.id;
        localStorage.setItem('camp_id', JSON.stringify({camp_id}));
        navigate('/MainPage');
    }
    return(
        <div className='board' onClick={handleClick}>
            <div className='camp-title'>{props.name}</div>
            <div className='camp-info'>
                Park id: {props.park_id}{"\n"}
                Latitude: {props.lat}{"\n"}
                Longitude: {props.lon}
            </div>
        </div>
    );
}

export default Campsite;