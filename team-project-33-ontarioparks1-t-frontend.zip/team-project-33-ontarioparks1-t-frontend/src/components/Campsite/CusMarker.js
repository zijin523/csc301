import { Marker } from "@react-google-maps/api";
function CusMarker(props){
    let coords = {lat: props.lat, lng: props.lon};
    return (
        <Marker position={coords} icon={{url:'https://static.thenounproject.com/png/118331-200.png', 
        scaledSize: new google.maps.Size(31, 31)}}></Marker>
    );
}
export default CusMarker;