import '../Campsite/Campsite.css';
import ImageSlider from "../ImageSlider/ImageSlider.jsx";

function PostComp(props){
    return(
        <div className='board'>
            <h4>Post Id: {props.id}</h4>
            <div className='camp-title'>
                campsite Id: {props.campsite_id}, {'\n'}
                email: {props.email}, {'\n'}
                name: {props.name}, {'\n'}
                post time: {props.post_time}
            </div>
            <div className='camp-info'>
                content: {props.content}
            </div>
            <ImageSlider images={props.images} content={""}/>
        </div>
    );
}

export default PostComp;