import { useState } from "react";
import classes from './ImageSlider.module.css';

const ImageSlider = (props) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    
    const goPrev = () => {
        const newIndex = (currentIndex === 0) ? props.slides.images.length -1 : currentIndex - 1;
        setCurrentIndex(newIndex);
    }

    const goNext = () => {
        const newIndex = (currentIndex === props.slides.images.length - 1) ? 0 : currentIndex + 1;
        setCurrentIndex(newIndex);
    }
    return (
    <div className={classes.slider}>
        <div className={classes.leftArrow} onClick={goPrev}> 《 </div>
        <img className={classes.slide} src={props.slides.images[currentIndex]} alt={props.slides.title} />
        <div className={classes.rightArrow} onClick={goNext}> 》 </div>   
    </div>
    );
};

export default ImageSlider;