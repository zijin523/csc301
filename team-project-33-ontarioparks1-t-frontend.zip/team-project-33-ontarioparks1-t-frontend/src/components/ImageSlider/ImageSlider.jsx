import { useState } from 'react';
import './ImageSlider.css';

function ImageSlider(props) {
  const { images, content } = props;

  const [activeIndex, setActiveIndex] = useState(0);
  const [expand, setExpand] = useState(false);

  const showArrow = expand && images.length > 1;

  const handleClick = () => {
    setExpand(!expand);
  };

  const handlePrev = () => {
    if (activeIndex > 0) {
      setActiveIndex(activeIndex - 1);
    } else {
      setActiveIndex(images.length - 1);
    }
  };

  const handleNext = () => {
    if (activeIndex < images.length - 1) {
      setActiveIndex(activeIndex + 1);
    } else {
      setActiveIndex(0);
    }
  };

  return (
    <div className="slider">
      <div className="slider-images">
        {images[activeIndex] && (
          <img
            src={images[activeIndex]}
            className={`slider-image ${
              expand ? 'slider-image-expand' : 'slider-image-unExpand'
            }`}
            alt="image"
            onClick={handleClick}
          />
        )}

        {showArrow && (
          <div className="slider-prev" onClick={handlePrev}>
            {'<'}
          </div>
        )}

        {showArrow && (
          <div className="slider-next" onClick={handleNext}>
            {'>'}
          </div>
        )}

        {showArrow && (
          <div className="slider-dots">
            {new Array(images.length).fill(true).map((item, index) => (
              <span
                className={`slider-dots-item ${
                  index === activeIndex
                    ? 'slider-dots-item-active'
                    : 'slider-dots-item-inactive'
                }`}
                key={index}
                onClick={() => setActiveIndex(index)}
              />
            ))}
          </div>
        )}
      </div>
      {expand && <div className="slider-text">{content}</div>}
    </div>
  );
}

export default ImageSlider;
